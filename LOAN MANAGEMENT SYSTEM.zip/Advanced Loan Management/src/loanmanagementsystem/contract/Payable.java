package loanmanagementsystem.contract;

public interface Payable {
    
    
    boolean processPayment(double amountPaid);
    
    
    double calculateRemainingBalance();
    
    
    String generatePaymentReceipt();
}
