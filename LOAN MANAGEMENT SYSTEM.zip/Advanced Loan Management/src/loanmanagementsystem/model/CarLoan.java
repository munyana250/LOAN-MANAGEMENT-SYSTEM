package loanmanagementsystem.model;

/**
 * CarLoan Class
 * Subclass of LoanManager for vehicle/auto loans
 * Specific Attribute: Vehicle Type
 */
public class CarLoan extends LoanManager {

    private String vehicleType;

    // ===== CONSTRUCTORS =====

    public CarLoan() {
        super();
    }

    public CarLoan(String loanID, String loanType, double loanAmount, 
                  double interestRate, int loanDuration, 
                  String officerName, String branchLocation, 
                  String vehicleType) {
        super(loanID, loanType, loanAmount, interestRate, loanDuration, officerName, branchLocation);
        this.vehicleType = vehicleType;
    }

    // ===== GETTERS AND SETTERS =====

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    // ===== OVERRIDE METHODS =====

    @Override
    public double calculateInterest() {
        // Car loans have standard interest rates
        // Add 0.5% extra for luxury vehicles
        double baseInterest = super.calculateInterest();
        if ("LUXURY".equalsIgnoreCase(vehicleType)) {
            return baseInterest * 1.005;
        }
        return baseInterest;
    }

    @Override
    public boolean checkEligibility() {
        // Car loan eligibility: max amount 30M RWF
        return getLoanAmount() <= 30000000 && validateLoanDetails();
    }

    @Override
    public String generateLoanReport() {
        return super.generateLoanReport() + 
               "Vehicle Type: " + vehicleType + "\n";
    }

    @Override
    public String toString() {
        return "CarLoan{" +
                super.toString() +
                ", vehicleType='" + vehicleType + '\'' +
                '}';
    }
}
