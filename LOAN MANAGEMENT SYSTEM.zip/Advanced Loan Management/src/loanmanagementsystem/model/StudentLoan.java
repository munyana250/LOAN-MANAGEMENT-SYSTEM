package loanmanagementsystem.model;

/**
 * StudentLoan Class
 * Subclass of LoanManager for student loans
 * Specific Attribute: University Name
 */
public class StudentLoan extends LoanManager {

    private String universityName;

    // ===== CONSTRUCTORS =====

    public StudentLoan() {
        super();
    }

    public StudentLoan(String loanID, String loanType, double loanAmount, 
                      double interestRate, int loanDuration, 
                      String officerName, String branchLocation, 
                      String universityName) {
        super(loanID, loanType, loanAmount, interestRate, loanDuration, officerName, branchLocation);
        this.universityName = universityName;
    }

    // ===== GETTERS AND SETTERS =====

    public String getUniversityName() {
        return universityName;
    }

    public void setUniversityName(String universityName) {
        this.universityName = universityName;
    }

    // ===== OVERRIDE METHODS =====

    @Override
    public double calculateInterest() {
        // Student loans have special rates - typically lower
        double baseInterest = super.calculateInterest();
        // Reduce by 1.5% for student loans as they are government encouraged
        return baseInterest * 0.985;
    }

    @Override
    public boolean checkEligibility() {
        // Student loan eligibility: max amount 15M RWF and must be enrolled
        return getLoanAmount() <= 15000000 && 
               universityName != null && !universityName.isEmpty() && 
               validateLoanDetails();
    }

    @Override
    public String generateLoanReport() {
        return super.generateLoanReport() + 
               "University Name: " + universityName + "\n";
    }

    @Override
    public String toString() {
        return "StudentLoan{" +
                super.toString() +
                ", universityName='" + universityName + '\'' +
                '}';
    }
}
