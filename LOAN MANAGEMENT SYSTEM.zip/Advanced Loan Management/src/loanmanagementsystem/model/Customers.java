/**
 * Customer Class
 * Represents a bank customer with personal information
 */
package loanmanagementsystem.model;

public class Customers {

    private String customerName;
    private String customerID;
    private String nationalID;
    private String phoneNumber;

    // ===== CONSTRUCTORS =====

    /**
     * Default Constructor
     */
    public Customers() {
    }

    /**
     * Parameterized Constructor
     */
    public Customers(String customerID, String customerName, String nationalID, String phoneNumber) {
        this.customerName = customerName;
        this.customerID = customerID;
        this.nationalID = nationalID;
        this.phoneNumber = phoneNumber;
    }

    // ===== GETTERS AND SETTERS =====

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerID() {
        return customerID;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }

    public String getNationalID() {
        return nationalID;
    }

    public void setNationalID(String nationalID) {
        this.nationalID = nationalID;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    // ===== OVERRIDE toString() =====

    @Override
    public String toString() {
        return "\n╔════════════════════════════════════════════╗\n" +
                "║         CUSTOMER DETAILS                   ║\n" +
                "╚════════════════════════════════════════════╝\n" +
                "Customer ID: " + customerID + "\n" +
                "Customer Name: " + customerName + "\n" +
                "National ID: " + nationalID + "\n" +
                "Phone Number: " + phoneNumber + "\n" +
                "════════════════════════════════════════════\n";
    }
}
