package loanmanagementsystem.model;


public class AgriculturalLoan extends LoanManager {

    private double farmSize;

    // ===== CONSTRUCTORS =====

    public AgriculturalLoan() {
        super();
    }

    public AgriculturalLoan(String loanID, String loanType, double loanAmount, 
                           double interestRate, int loanDuration, 
                           String officerName, String branchLocation, 
                           double farmSize) {
        super(loanID, loanType, loanAmount, interestRate, loanDuration, officerName, branchLocation);
        this.farmSize = farmSize;
    }

    // ===== GETTERS AND SETTERS =====

    public double getFarmSize() {
        return farmSize;
    }

    public void setFarmSize(double farmSize) {
        this.farmSize = farmSize;
    }

    // ===== OVERRIDE METHODS =====

    @Override
    public double calculateInterest() {
        // Agricultural loans have government subsidized rates
        double baseInterest = super.calculateInterest();
        // Reduce by 2% for government agricultural support
        return baseInterest * 0.98;
    }

    @Override
    public boolean checkEligibility() {
        // Agricultural loan eligibility: farm size must be at least 0.5 hectares
        // and max amount 40M RWF
        return farmSize >= 0.5 && 
               getLoanAmount() <= 40000000 && 
               validateLoanDetails();
    }

    @Override
    public String generateLoanReport() {
        return super.generateLoanReport() + 
               "Farm Size: " + String.format("%.2f", farmSize) + " hectares\n";
    }

    @Override
    public String toString() {
        return "AgriculturalLoan{" +
                super.toString() +
                ", farmSize=" + farmSize +
                '}';
    }
}
