package loanmanagementsystem.model;

/**
 * BusinessLoan Class
 * Subclass of LoanManager for business loans
 * Specific Attribute: Business Type
 */
public class BusinessLoan extends LoanManager {

    private String businessType;

    // ===== CONSTRUCTORS =====

    public BusinessLoan() {
        super();
    }

    public BusinessLoan(String loanID, String loanType, double loanAmount, 
                       double interestRate, int loanDuration, 
                       String officerName, String branchLocation, 
                       String businessType) {
        super(loanID, loanType, loanAmount, interestRate, loanDuration, officerName, branchLocation);
        this.businessType = businessType;
    }

    // ===== GETTERS AND SETTERS =====

    public String getBusinessType() {
        return businessType;
    }

    public void setBusinessType(String businessType) {
        this.businessType = businessType;
    }

    // ===== OVERRIDE METHODS =====

    @Override
    public double calculateInterest() {
        // Business loans have higher interest rates due to higher risk
        double baseInterest = super.calculateInterest();
        // Reduce 1% for established businesses (non-startup)
        if ("ESTABLISHED".equalsIgnoreCase(businessType)) {
            return baseInterest * 0.99;
        }
        return baseInterest;
    }

    @Override
    public boolean checkEligibility() {
        // Business loan eligibility: amount can be higher (up to 200M)
        return getLoanAmount() <= 200000000 && validateLoanDetails();
    }

    @Override
    public String generateLoanReport() {
        return super.generateLoanReport() + 
               "Business Type: " + businessType + "\n";
    }

    @Override
    public String toString() {
        return "BusinessLoan{" +
                super.toString() +
                ", businessType='" + businessType + '\'' +
                '}';
    }
}
