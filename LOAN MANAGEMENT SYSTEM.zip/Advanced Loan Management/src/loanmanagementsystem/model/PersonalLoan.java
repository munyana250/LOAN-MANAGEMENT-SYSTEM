package loanmanagementsystem.model;

/**
 * PersonalLoan Class
 * Subclass of LoanManager for personal loans
 * Specific Attribute: Employment Status
 */
public class PersonalLoan extends LoanManager {

    private String employmentStatus;

    // ===== CONSTRUCTORS =====

    public PersonalLoan() {
        super();
    }

    public PersonalLoan(String loanID, String loanType, double loanAmount, 
                       double interestRate, int loanDuration, 
                       String officerName, String branchLocation, 
                       String employmentStatus) {
        super(loanID, loanType, loanAmount, interestRate, loanDuration, officerName, branchLocation);
        this.employmentStatus = employmentStatus;
    }

    // ===== GETTERS AND SETTERS =====

    public String getEmploymentStatus() {
        return employmentStatus;
    }

    public void setEmploymentStatus(String employmentStatus) {
        this.employmentStatus = employmentStatus;
    }

    // ===== OVERRIDE METHODS =====

    @Override
    public double calculateInterest() {
        // Personal loans have a base interest rate
        double baseInterest = super.calculateInterest();
        // Add 2% extra if unemployed
        if ("UNEMPLOYED".equalsIgnoreCase(employmentStatus)) {
            return baseInterest * 1.02;
        }
        return baseInterest;
    }

    @Override
    public boolean checkEligibility() {
        // Personal loan eligibility: max amount 50M RWF
        return getLoanAmount() <= 50000000 && validateLoanDetails();
    }

    @Override
    public String generateLoanReport() {
        return super.generateLoanReport() + 
               "Employment Status: " + employmentStatus + "\n";
    }

    @Override
    public String toString() {
        return "PersonalLoan{" +
                super.toString() +
                ", employmentStatus='" + employmentStatus + '\'' +
                '}';
    }
}
