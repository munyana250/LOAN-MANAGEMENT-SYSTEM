package loanmanagementsystem.model;

/**
 * Repayment Class
 * Tracks payment information for loans
 */
public class Repayment {

    private String paymentID;
    private LoanManager loan;
    private double amountPaid;
    private String paymentDate;
    private double remainingBalance;

    // ===== CONSTRUCTORS =====

    /**
     * Default Constructor
     */
    public Repayment() {
    }

    /**
     * Parameterized Constructor
     */
    public Repayment(String paymentID, LoanManager loan, double amountPaid, 
                    String paymentDate, double remainingBalance) {
        this.paymentID = paymentID;
        this.loan = loan;
        this.amountPaid = amountPaid;
        this.paymentDate = paymentDate;
        this.remainingBalance = remainingBalance;
    }

    // ===== GETTERS AND SETTERS =====

    public String getPaymentID() {
        return paymentID;
    }

    public void setPaymentID(String paymentID) {
        this.paymentID = paymentID;
    }

    public LoanManager getLoan() {
        return loan;
    }

    public void setLoan(LoanManager loan) {
        this.loan = loan;
    }

    public double getAmountPaid() {
        return amountPaid;
    }

    public void setAmountPaid(double amountPaid) {
        this.amountPaid = amountPaid;
    }

    public String getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(String paymentDate) {
        this.paymentDate = paymentDate;
    }

    public double getRemainingBalance() {
        return remainingBalance;
    }

    public void setRemainingBalance(double remainingBalance) {
        this.remainingBalance = remainingBalance;
    }

    // ===== METHODS =====

    /**
     * Update remaining balance after a payment
     * @param paymentAmount The amount being paid
     */
    public void updateRemainingBalance(double paymentAmount) {
        this.remainingBalance -= paymentAmount;
        if (this.remainingBalance < 0) {
            this.remainingBalance = 0;
        }
    }

    /**
     * Get payment status summary
     * @return Payment status as string
     */
    public String getPaymentStatus() {
        if (remainingBalance <= 0) {
            return "FULLY PAID";
        } else if (remainingBalance == loan.calculateTotalRepayment()) {
            return "NO PAYMENT MADE";
        } else {
            return "PARTIALLY PAID";
        }
    }

    // ===== OVERRIDE toString() =====

    @Override
    public String toString() {
        return "\n╔════════════════════════════════════════════╗\n" +
                "║         REPAYMENT DETAILS                  ║\n" +
                "╚════════════════════════════════════════════╝\n" +
                "Payment ID: " + paymentID + "\n" +
                "Loan ID: " + (loan != null ? loan.getLoanID() : "N/A") + "\n" +
                "Amount Paid: RWF " + String.format("%.2f", amountPaid) + "\n" +
                "Payment Date: " + paymentDate + "\n" +
                "Remaining Balance: RWF " + String.format("%.2f", remainingBalance) + "\n" +
                "Payment Status: " + getPaymentStatus() + "\n" +
                "════════════════════════════════════════════\n";
    }
}
