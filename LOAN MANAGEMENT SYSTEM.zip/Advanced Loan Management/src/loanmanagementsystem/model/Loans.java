/**
 * Abstract Class: Loan
 * Base class for all loan types with encapsulation and abstract methods
 */
package loanmanagementsystem.model;

public abstract class Loans {

    // Private attributes (Encapsulation)
    private String loanID;
    private String loanType;
    private double loanAmount;
    private double interestRate;
    private int loanDuration; // in months
    private String loanStatus; // PENDING, APPROVED, REJECTED, CLOSED

    // ===== CONSTRUCTORS =====
    
    /**
     * Default Constructor
     */
    public Loans() {
        this.loanStatus = "PENDING";
    }

    /**
     * Parameterized Constructor
     */
    public Loans(String loanID, String loanType, double loanAmount, double interestRate, int loanDuration) {
        this.loanID = loanID;
        this.loanType = loanType;
        this.loanAmount = loanAmount;
        this.interestRate = interestRate;
        this.loanDuration = loanDuration;
        this.loanStatus = "PENDING";
    }

    // ===== GETTERS AND SETTERS =====

    public String getLoanID() {
        return loanID;
    }

    public void setLoanID(String loanID) {
        this.loanID = loanID;
    }

    public String getLoanType() {
        return loanType;
    }

    public void setLoanType(String loanType) {
        this.loanType = loanType;
    }

    public double getLoanAmount() {
        return loanAmount;
    }

    public void setLoanAmount(double loanAmount) {
        this.loanAmount = loanAmount;
    }

    public double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }

    public int getLoanDuration() {
        return loanDuration;
    }

    public void setLoanDuration(int loanDuration) {
        this.loanDuration = loanDuration;
    }

    public String getLoanStatus() {
        return loanStatus;
    }

    public void setLoanStatus(String loanStatus) {
        this.loanStatus = loanStatus;
    }

    // ===== ABSTRACT METHODS (at least 8) =====

    /**
     * Calculate the interest amount based on loan details
     * @return The calculated interest amount
     */
    public abstract double calculateInterest();

    /**
     * Calculate the monthly installment amount
     * @return The monthly installment amount
     */
    public abstract double calculateMonthlyInstallment();

    /**
     * Check if customer is eligible for this loan type
     * @return true if eligible, false otherwise
     */
    public abstract boolean checkEligibility();

    /**
     * Approve the loan application
     * @return true if approval successful
     */
    public abstract boolean approveLoan();

    /**
     * Reject the loan application
     * @param reason The reason for rejection
     * @return true if rejection successful
     */
    public abstract boolean rejectLoan(String reason);

    /**
     * Calculate total amount to be repaid (Principal + Interest)
     * @return The total repayment amount
     */
    public abstract double calculateTotalRepayment();

    /**
     * Generate a comprehensive loan report
     * @return Formatted loan report as string
     */
    public abstract String generateLoanReport();

    /**
     * Validate all loan details for correctness
     * @return true if all details are valid, false otherwise
     */
    public abstract boolean validateLoanDetails();

    // ===== OVERRIDE toString() =====

    @Override
    public String toString() {
        return "Loans{" +
                "loanID='" + loanID + '\'' +
                ", loanType='" + loanType + '\'' +
                ", loanAmount=" + loanAmount +
                ", interestRate=" + interestRate + "%" +
                ", loanDuration=" + loanDuration + " months" +
                ", loanStatus='" + loanStatus + '\'' +
                '}';
    }
}
