package loanmanagementsystem.model;

import loanmanagementsystem.contract.Payable;

/**
 * Class: LoanManager
 * Extends Loan and implements Payable
 * Manages loan operations with officer details
 */
public class LoanManager extends Loans implements Payable {

    // Additional attributes specific to LoanManager
    private String officerName;
    private String branchLocation;
    private String customerID;
    private String customerName;
    private String customerNationalId;
    private double amountPaid;
    private double remainingBalance;

    // ===== CONSTRUCTORS =====

    /**
     * Default Constructor
     */
    public LoanManager() {
        super();
        this.amountPaid = 0;
        this.remainingBalance = 0;
    }

    /**
     * Parameterized Constructor
     */
    public LoanManager(String loanID, String loanType, double loanAmount, 
                      double interestRate, int loanDuration, 
                      String officerName, String branchLocation) {
        super(loanID, loanType, loanAmount, interestRate, loanDuration);
        this.officerName = officerName;
        this.branchLocation = branchLocation;
        this.amountPaid = 0;
        this.remainingBalance = calculateTotalRepayment();
    }

    // ===== GETTERS AND SETTERS =====

    public String getOfficerName() {
        return officerName;
    }

    public void setOfficerName(String officerName) {
        this.officerName = officerName;
    }

    public String getBranchLocation() {
        return branchLocation;
    }

    public void setBranchLocation(String branchLocation) {
        this.branchLocation = branchLocation;
    }

    public double getAmountPaid() {
        return amountPaid;
    }

    public void setAmountPaid(double amountPaid) {
        this.amountPaid = amountPaid;
    }

    public double getRemainingBalance() {
        return remainingBalance;
    }

    public void setRemainingBalance(double remainingBalance) {
        this.remainingBalance = remainingBalance;
    }

    // ===== IMPLEMENT ABSTRACT METHODS FROM LOANS =====

    @Override
    public double calculateInterest() {
        return getLoanAmount() * getInterestRate() / 100;
    }

    @Override
    public double calculateMonthlyInstallment() {
        double totalRepayment = calculateTotalRepayment();
        return totalRepayment / getLoanDuration();
    }

    @Override
    public boolean checkEligibility() {
        // Basic eligibility check - can be overridden by subclasses
        return validateLoanDetails();
    }

    @Override
    public boolean approveLoan() {
        if (validateLoanDetails()) {
            setLoanStatus("APPROVED");
            remainingBalance = calculateTotalRepayment();
            return true;
        }
        return false;
    }

    @Override
    public boolean rejectLoan(String reason) {
        setLoanStatus("REJECTED");
        System.out.println("Loan Rejection Reason: " + reason);
        return true;
    }

    @Override
    public double calculateTotalRepayment() {
        return getLoanAmount() + calculateInterest();
    }

    @Override
    public String generateLoanReport() {
        StringBuilder report = new StringBuilder();
        report.append("\n╔════════════════════════════════════════════╗\n");
        report.append("║         LOAN REPORT                         ║\n");
        report.append("╚════════════════════════════════════════════╝\n");
        report.append("Loan ID: ").append(getLoanID()).append("\n");
        report.append("Customer ID: ").append(customerID != null ? customerID : "N/A").append("\n");
        report.append("Customer Name: ").append(customerName != null ? customerName : "N/A").append("\n");
        report.append("Customer National ID: ").append(customerNationalId != null ? customerNationalId : "N/A").append("\n");
        report.append("Loan Type: ").append(getLoanType()).append("\n");
        report.append("Principal Amount: RWF ").append(String.format("%.2f", getLoanAmount())).append("\n");
        report.append("Interest Rate: ").append(String.format("%.2f", getInterestRate())).append("%\n");
        report.append("Interest Amount: RWF ").append(String.format("%.2f", calculateInterest())).append("\n");
        report.append("Total Repayment: RWF ").append(String.format("%.2f", calculateTotalRepayment())).append("\n");
        report.append("Loan Duration: ").append(getLoanDuration()).append(" months\n");
        report.append("Monthly Installment: RWF ").append(String.format("%.2f", calculateMonthlyInstallment())).append("\n");
        report.append("Loan Status: ").append(getLoanStatus()).append("\n");
        report.append("Officer Name: ").append(officerName).append("\n");
        report.append("Branch Location: ").append(branchLocation).append("\n");
        report.append("Amount Paid: RWF ").append(String.format("%.2f", amountPaid)).append("\n");
        report.append("Remaining Balance: RWF ").append(String.format("%.2f", remainingBalance)).append("\n");
        report.append("════════════════════════════════════════════\n");
        return report.toString();
    }

    @Override
    public boolean validateLoanDetails() {
        return getLoanID() != null && !getLoanID().isEmpty() &&
               getLoanType() != null && !getLoanType().isEmpty() &&
               getLoanAmount() > 0 &&
               getInterestRate() > 0 &&
               getInterestRate() <= 100 &&
               getLoanDuration() > 0 &&
               officerName != null && !officerName.isEmpty() &&
               branchLocation != null && !branchLocation.isEmpty() &&
               customerID != null && !customerID.isEmpty() &&
               customerName != null && !customerName.isEmpty() &&
               customerNationalId != null && !customerNationalId.isEmpty();
    }

    // ===== IMPLEMENT PAYABLE INTERFACE METHODS =====

    @Override
    public boolean processPayment(double amountPaid) {
        if (amountPaid <= 0) {
            System.out.println("Invalid payment amount. Must be greater than 0.");
            return false;
        }

        if (amountPaid > remainingBalance) {
            System.out.println("Payment exceeds remaining balance of RWF " + String.format("%.2f", remainingBalance));
            return false;
        }

        this.amountPaid += amountPaid;
        this.remainingBalance -= amountPaid;

        if (remainingBalance <= 0) {
            setLoanStatus("CLOSED");
        }

        return true;
    }

    @Override
    public double calculateRemainingBalance() {
        return remainingBalance;
    }

    @Override
    public String generatePaymentReceipt() {
        StringBuilder receipt = new StringBuilder();
        receipt.append("\n╔════════════════════════════════════════════╗\n");
        receipt.append("║         PAYMENT RECEIPT                     ║\n");
        receipt.append("╚════════════════════════════════════════════╝\n");
        receipt.append("Loan ID: ").append(getLoanID()).append("\n");
        receipt.append("Payment Amount: RWF ").append(String.format("%.2f", amountPaid)).append("\n");
        receipt.append("Total Paid: RWF ").append(String.format("%.2f", amountPaid)).append("\n");
        receipt.append("Remaining Balance: RWF ").append(String.format("%.2f", remainingBalance)).append("\n");
        receipt.append("Loan Status: ").append(getLoanStatus()).append("\n");
        receipt.append("════════════════════════════════════════════\n");
        return receipt.toString();
    }

    // ===== OVERRIDE toString() =====

    public void setCustomerInfo(Customers customer) {
        if (customer != null) {
            this.customerID = customer.getCustomerID();
            this.customerName = customer.getCustomerName();
            this.customerNationalId = customer.getNationalID();
        }
    }

    public String getCustomerID() {
        return customerID;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getCustomerNationalId() {
        return customerNationalId;
    }

    @Override
    public String toString() {
        return "LoanManager{" +
                "loanID='" + getLoanID() + '\'' +
                ", loanType='" + getLoanType() + '\'' +
                ", loanAmount=" + getLoanAmount() +
                ", interestRate=" + getInterestRate() + "%" +
                ", loanDuration=" + getLoanDuration() + " months" +
                ", loanStatus='" + getLoanStatus() + '\'' +
                ", officerName='" + officerName + '\'' +
                ", branchLocation='" + branchLocation + '\'' +
                ", customerID='" + customerID + '\'' +
                ", customerName='" + customerName + '\'' +
                ", customerNationalId='" + customerNationalId + '\'' +
                ", amountPaid=" + amountPaid +
                ", remainingBalance=" + remainingBalance +
                '}';
    }
}
