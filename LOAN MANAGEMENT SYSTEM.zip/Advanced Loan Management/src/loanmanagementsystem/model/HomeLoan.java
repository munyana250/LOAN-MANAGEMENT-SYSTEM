package loanmanagementsystem.model;

/**
 * HomeLoan Class
 * Subclass of LoanManager for home/mortgage loans
 * Specific Attribute: Property Value
 */
public class HomeLoan extends LoanManager {

    private double propertyValue;

    // ===== CONSTRUCTORS =====

    public HomeLoan() {
        super();
    }

    public HomeLoan(String loanID, String loanType, double loanAmount, 
                   double interestRate, int loanDuration, 
                   String officerName, String branchLocation, 
                   double propertyValue) {
        super(loanID, loanType, loanAmount, interestRate, loanDuration, officerName, branchLocation);
        this.propertyValue = propertyValue;
    }

    // ===== GETTERS AND SETTERS =====

    public double getPropertyValue() {
        return propertyValue;
    }

    public void setPropertyValue(double propertyValue) {
        this.propertyValue = propertyValue;
    }

    // ===== OVERRIDE METHODS =====

    @Override
    public double calculateInterest() {
        // Home loans have lower interest rates
        double baseInterest = super.calculateInterest();
        // Reduce by 1% for good collateral ratio (loan < 80% of property value)
        if (getLoanAmount() < propertyValue * 0.80) {
            return baseInterest * 0.99;
        }
        return baseInterest;
    }

    @Override
    public boolean checkEligibility() {
        // Home loan eligibility: loan amount must not exceed 85% of property value
        return getLoanAmount() <= propertyValue * 0.85 && validateLoanDetails();
    }

    @Override
    public String generateLoanReport() {
        return super.generateLoanReport() + 
               "Property Value: RWF " + String.format("%.2f", propertyValue) + "\n" +
               "Loan to Value Ratio: " + String.format("%.2f", (getLoanAmount() / propertyValue) * 100) + "%\n";
    }

    @Override
    public String toString() {
        return "HomeLoan{" +
                super.toString() +
                ", propertyValue=" + propertyValue +
                '}';
    }
}
