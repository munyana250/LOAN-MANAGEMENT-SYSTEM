
package loanmanagementsystem.ui;


public class Main extends MenuHelpers {

    public static void main(String[] args) {
        String choice;
        
        System.out.println("╔════════════════════════════════════════════╗");
        System.out.println("║   BANK OF KIGALI LOAN MANAGEMENT SYSTEM   ║");
        System.out.println("║         OOP Java Implementation            ║");
        System.out.println("╚════════════════════════════════════════════╝");

        do {
            printMainMenu();
            System.out.print("  Enter choice: ");
            choice = scanner.nextLine().trim();

            switch (choice) {
                case "1" -> customerRegistration();
                case "2" -> loanApplication();
                case "3" -> approveLoan();
                case "4" -> makePayment();
                case "5" -> viewLoanDetails();
                case "6" -> viewCustomerDetails();
                case "7" -> viewRepaymentHistory();
                case "8" -> viewAllLoans();
                case "0" -> {
                    System.out.println("\n╔════════════════════════════════════════════╗");
                    System.out.println("║       Thank you for using our system       ║");
                    System.out.println("║           GOODBYE!                         ║");
                    System.out.println("╚════════════════════════════════════════════╝\n");
                }
                default -> System.out.println("Invalid choice. Please try again.");
            }
        } while (!choice.equals("0"));
        scanner.close();
    }
}


