package loanmanagementsystem.ui;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import loanmanagementsystem.model.Customers;
import loanmanagementsystem.model.LoanManager;
import loanmanagementsystem.model.Repayment;
import loanmanagementsystem.service.LoanFactory;
import loanmanagementsystem.util.InputValidator;


public class MenuHelpers {

    protected static final Scanner scanner = new Scanner(System.in);
    protected static final List<Customers> customersList = new ArrayList<>();
    protected static final List<LoanManager> loanList = new ArrayList<>();
    protected static final List<Repayment> repaymentList = new ArrayList<>();

    // ===== MAIN MENU =====

    protected static void printMainMenu() {
        System.out.println("\n┌──────────────────────────────────────────┐");
        System.out.println("│     BANK OF KIGALI LOAN SYSTEM            │");
        System.out.println("│               MAIN MENU                   │");
        System.out.println("├──────────────────────────────────────────┤");
        System.out.println("│  1. Register New Customer                │");
        System.out.println("│  2. Apply for a Loan                     │");
        System.out.println("│  3. Approve / Reject Loan                │");
        System.out.println("│  4. Make a Payment                       │");
        System.out.println("│  5. View Loan Details & Report           │");
        System.out.println("│  6. View Customer Details                │");
        System.out.println("│  7. View Repayment History               │");
        System.out.println("│  8. View All Loans                       │");
        System.out.println("│  0. Exit                                 │");
        System.out.println("└──────────────────────────────────────────┘");
     
    }

    // ===== OPTION 1: CUSTOMER REGISTRATION =====

    protected static void customerRegistration() {
        System.out.println("\n┌──────────────────────────────────────────┐");
        System.out.println("│      CUSTOMER REGISTRATION               │");
        System.out.println("└──────────────────────────────────────────┘");

        String cusID;
        do {
            System.out.print("Enter new CUSTOMER-ID (CUS-XXXXX): ");
            cusID = scanner.nextLine().toUpperCase();
        } while (!InputValidator.validateCustomerIds(cusID));

        String names;
        do {
            System.out.print("CUSTOMER-NAMES: ");
            names = scanner.nextLine().toUpperCase();
        } while (!InputValidator.validateNames(names));

        String nationalID;
        do {
            System.out.print("CUSTOMER-NATIONAL-ID (16 digits): ");
            nationalID = scanner.nextLine();
        } while (!InputValidator.validateNationalId(nationalID));

        String phoneNumber;
        do {
            System.out.print("CUSTOMER-PHONE NUMBER (+250XXXXXXXXX): ");
            phoneNumber = scanner.nextLine();
        } while (!InputValidator.validatePhoneNumber(phoneNumber));

        Customers newCustomer = new Customers(cusID, names, nationalID, phoneNumber);
        customersList.add(newCustomer);
        System.out.println("\n✓ Customer registered successfully!");
        System.out.println(newCustomer);

        System.out.println("\n press ENTER to return to main menu...");
        scanner.nextLine();
    }

    // ===== OPTION 2: LOAN APPLICATION =====

    protected static void loanApplication() {
        System.out.println("\n┌──────────────────────────────────────────┐");
        System.out.println("│         LOAN APPLICATION                 │");
        System.out.println("└──────────────────────────────────────────┘");

        if (customersList.isEmpty()) {
            System.out.println("No customers registered. Please register a customer first.");
            return;
        }

        // Find customer
        String cusId;
        Customers customer;
        do {
            System.out.print("Enter CUSTOMER ID: ");
            cusId = scanner.nextLine().toUpperCase().trim();
            customer = findCustomerById(cusId);
            if (customer == null) {
                System.out.println("Customer ID " + cusId + " not found.");
            }
        } while (customer == null);

        // Get loan ID
        String loanId;
        do {
            System.out.print("NEW LOAN ID (LN-XXXXX): ");
            loanId = scanner.nextLine().toUpperCase();
        } while (!InputValidator.validateloanIds(loanId));

        // Get loan amount
        String loanAmountStr;
        do {
            System.out.print("Loan Amount (RWF): ");
            loanAmountStr = scanner.nextLine();
        } while (!InputValidator.validateMoneyAmount(loanAmountStr));
        double loanAmount = Double.parseDouble(loanAmountStr);

        // Display loan types
        LoanFactory.displayLoanTypes();
        
        // Get loan type
        String loanType;
        do {
            System.out.print("Select Loan Type (1-6 or name): ");
            loanType = scanner.nextLine();
        } while (!InputValidator.validateloanType(loanType));

        // Get interest rate
        String interestRateStr;
        do {
            System.out.print("Interest Rate (%): ");
            interestRateStr = scanner.nextLine();
        } while (!InputValidator.validateInterestRate(interestRateStr));
        double interestRate = Double.parseDouble(interestRateStr);

        // Get loan duration
        String durationStr;
        do {
            System.out.print("Loan Duration (months): ");
            durationStr = scanner.nextLine();
        } while (!InputValidator.validateLoanDuration(durationStr));
        int duration = Integer.parseInt(durationStr);

        // Get type-specific attribute
        String specificAttribute = getTypeSpecificAttribute(loanType);

        // Officer details
        String officerName;
        do {
            System.out.print("Loan Officer Name: ");
            officerName = scanner.nextLine().toUpperCase().trim();
        } while (!InputValidator.validateNames(officerName));

        String branchLocation;
        do {
            System.out.print("Branch Location: ");
            branchLocation = scanner.nextLine().toUpperCase().trim();
        } while (!InputValidator.validateLocation(branchLocation));

        // Create loan using factory
        LoanManager newLoan = LoanFactory.createLoan(loanType, loanId, loanAmount,
                                                      interestRate, duration,
                                                      officerName, branchLocation,
                                                      specificAttribute);

        if (newLoan != null) {
            newLoan.setCustomerInfo(customer);
        }

        if (newLoan != null && newLoan.validateLoanDetails()) {
            loanList.add(newLoan);
            System.out.println("\n✓ Loan application submitted successfully!");
            System.out.println(newLoan.generateLoanReport());
        } else {
            System.out.println("\n✗ Failed to create loan. Invalid details.");
        }

        System.out.println("\n press ENTER to return to main menu...");
        scanner.nextLine();

    }

    // ===== OPTION 3: APPROVE / REJECT LOAN =====

    protected static void approveLoan() {
        System.out.println("\n┌──────────────────────────────────────────┐");
        System.out.println("│    LOAN APPROVAL / REJECTION             │");
        System.out.println("└──────────────────────────────────────────┘");

        if (loanList.isEmpty()) {
            System.out.println("No loans to approve/reject.");
            return;
        }

        displayAllLoans();

        String loanId;
        System.out.print("Enter LOAN ID to process: ");
        loanId = scanner.nextLine().toUpperCase();

        LoanManager loan = findLoanById(loanId);
        if (loan == null) {
            System.out.println("Loan ID not found.");
            return;
        }

        System.out.println("\nCurrent Status: " + loan.getLoanStatus());
        System.out.println("1. Approve Loan");
        System.out.println("2. Reject Loan");
        System.out.print("Choose action (1-2): ");
        String choice = scanner.nextLine();

        if (choice.equals("1")) {
            if (loan.checkEligibility()) {
                loan.approveLoan();
                System.out.println("✓ Loan APPROVED successfully!");
                System.out.println(loan.generateLoanReport());
            } else {
                System.out.println("✗ Loan does not meet eligibility requirements.");
            }
        } else if (choice.equals("2")) {
            System.out.print("Enter rejection reason: ");
            String reason = scanner.nextLine();
            loan.rejectLoan(reason);
            System.out.println("✓ Loan REJECTED.");
        } else {
            System.out.println("Invalid choice.");
        }

        System.out.println("\n press ENTER to return to main menu...");
        scanner.nextLine();

    }

    // ===== OPTION 4: MAKE A PAYMENT =====

    protected static void makePayment() {
        System.out.println("\n┌──────────────────────────────────────────┐");
        System.out.println("│          MAKE A PAYMENT                  │");
        System.out.println("└──────────────────────────────────────────┘");

        if (loanList.isEmpty()) {
            System.out.println("No loans available.");
            System.out.println("\n press ENTER to return to main menu...");
             scanner.nextLine();
            return;
        }

        displayApprovedLoans();

        String loanId;
        System.out.print("Enter LOAN ID for payment: ");
        loanId = scanner.nextLine().toUpperCase();

        LoanManager loan = findLoanById(loanId);
        if (loan == null || !loan.getLoanStatus().equals("APPROVED")) {
            System.out.println("Loan not found or not approved.");
            return;
        }

        System.out.println("\nLoan Details:");
        System.out.println("Total Amount Due: RWF " + String.format("%.2f", loan.calculateTotalRepayment()));
        System.out.println("Amount Paid: RWF " + String.format("%.2f", loan.getAmountPaid()));
        System.out.println("Remaining Balance: RWF " + String.format("%.2f", loan.getRemainingBalance()));

        String paymentAmountStr;
        do {
            System.out.print("Enter payment amount (RWF): ");
            paymentAmountStr = scanner.nextLine();
        } while (!InputValidator.validateMoneyAmount(paymentAmountStr));

        double paymentAmount = Double.parseDouble(paymentAmountStr);

        // Get payment ID
        String paymentId;
        do {
            System.out.print("Payment ID (PAY-XXXXX): ");
            paymentId = scanner.nextLine().toUpperCase();
        } while (!InputValidator.validatePaymentId(paymentId));

        if (loan.processPayment(paymentAmount)) {
            // Create repayment record
            Repayment payment = new Repayment(paymentId, loan, paymentAmount,
                    LocalDate.now().toString(), loan.getRemainingBalance());
            repaymentList.add(payment);
            System.out.println("✓ Payment processed successfully!");
            System.out.println(loan.generatePaymentReceipt());
            System.out.println(payment.toString());
        } else {
            System.out.println("✗ Payment failed. Check the amount and try again.");
        }

        System.out.println("\n press ENTER to return to main menu...");
        scanner.nextLine();
    }

    // ===== OPTION 5: VIEW LOAN DETAILS & REPORT =====

    protected static void viewLoanDetails() {
        System.out.println("\n┌──────────────────────────────────────────┐");
        System.out.println("│    VIEW LOAN DETAILS & REPORT            │");
        System.out.println("└──────────────────────────────────────────┘");

        if (loanList.isEmpty()) {
            System.out.println("No loans available.");
            System.out.println("\n press ENTER to return to main menu...");
        scanner.nextLine();
            return;
        }

        displayAllLoans();

        String searchInput;
        do {
            System.out.print("Enter LOAN ID or CUSTOMER NATIONAL ID (or ENTER to return): ");
            searchInput = scanner.nextLine().toUpperCase().trim();
            if (searchInput.isEmpty()) {
                System.out.println("Returning to main menu.");
                return;
            }

            if (searchInput.startsWith("LN-")) {
                LoanManager loan = findLoanById(searchInput);
                if (loan == null) {
                    System.out.println("Loan not found.");
                } else {
                    System.out.println(loan.generateLoanReport());
                    return;
                }
            } else if (searchInput.matches("^\\d{16}$")) {
                List<LoanManager> foundLoans = findLoansByCustomerNationalId(searchInput);
                if (foundLoans.isEmpty()) {
                    System.out.println("No loans found for that National ID.");
                } else {
                    System.out.println("\nLoans for National ID " + searchInput + ":");
                    System.out.println("──────────────────────────────────────────");
                    for (LoanManager loan : foundLoans) {
                        System.out.println("- " + loan.getLoanID() + " | " + loan.getLoanType() + " | " + loan.getLoanStatus() + " | Customer: " + loan.getCustomerName());
                    }
                    return;
                }
            } else {
                System.out.println("Invalid input. Please enter a valid LOAN ID or a 16-digit National ID.");
            }

        System.out.println("\n press ENTER to return to main menu...");
        scanner.nextLine();

        } while (true);

    }

    // ===== OPTION 6: VIEW CUSTOMER DETAILS =====
    protected static void viewCustomerDetails() {
        System.out.println("\n┌──────────────────────────────────────────┐");
        System.out.println("│    VIEW CUSTOMER DETAILS                 │");
        System.out.println("└──────────────────────────────────────────┘");

        if (customersList.isEmpty()) {
            System.out.println("No customers registered.");
            return;
        }

        System.out.println("\nAll Customers:");
        System.out.println("──────────────────────────────────────────");
        for (int i = 0; i < customersList.size(); i++) {
            System.out.println((i + 1) + ". " + customersList.get(i).getCustomerID() + 
                             " - " + customersList.get(i).getCustomerName());
        }

        String cusId;
        Customers customer;
        do {
            System.out.print("\nEnter CUSTOMER ID to view details (or ENTER to return): ");
            cusId = scanner.nextLine().toUpperCase().trim();
            if (cusId.isEmpty()) {
                System.out.println("Returning to main menu.");
                return;
            }

            customer = findCustomerById(cusId);
            if (customer == null) {
                System.out.println("Customer not found. Please try again or press ENTER to cancel.");
            }
        } while (customer == null);

        System.out.println(customer.toString());

         System.out.println("\n press ENTER to return to main menu...");
        scanner.nextLine();
    }

    // ===== OPTION 7: VIEW REPAYMENT HISTORY =====

    protected static void viewRepaymentHistory() {
        System.out.println("\n┌──────────────────────────────────────────┐");
        System.out.println("│     VIEW REPAYMENT HISTORY               │");
        System.out.println("└──────────────────────────────────────────┘");

        if (repaymentList.isEmpty()) {
            System.out.println("No repayment records available.");
            return;
        }

        System.out.println("\nAll Repayment Records:");
        System.out.println("──────────────────────────────────────────");
        for (int i = 0; i < repaymentList.size(); i++) {
            Repayment rep = repaymentList.get(i);
            System.out.println((i + 1) + ". " + rep.getPaymentID() + 
                             " - Loan: " + rep.getLoan().getLoanID() + 
                             " - Amount: RWF " + String.format("%.2f", rep.getAmountPaid()));
        }

        String paymentId;
        System.out.print("\nEnter PAYMENT ID to view details (or ENTER to skip): ");
        paymentId = scanner.nextLine().toUpperCase();

        if (!paymentId.isEmpty()) {
            for (Repayment rep : repaymentList) {
                if (rep.getPaymentID().equals(paymentId)) {
                    System.out.println(rep.toString());
                    return;
                }
            }
            System.out.println("Payment record not found.");
        }
        System.out.println("\n press ENTER to return to main menu...");
        scanner.nextLine();
    }

    // ===== OPTION 8: VIEW ALL LOANS =====

    protected static void viewAllLoans() {
        System.out.println("\n┌──────────────────────────────────────────┐");
        System.out.println("│           VIEW ALL LOANS                 │");
        System.out.println("└──────────────────────────────────────────┘");

        if (loanList.isEmpty()) {
            System.out.println("No loans available.");
            System.out.println("\n press ENTER to return to main menu...");
            scanner.nextLine();
            return;
        }

        displayAllLoans();
         System.out.println("\n press ENTER to return to main menu...");
        scanner.nextLine();
    }

    // ===== HELPER METHODS =====

    private static Customers findCustomerById(String cusId) {
        for (Customers customer : customersList) {
            if (customer.getCustomerID().equalsIgnoreCase(cusId)) {
                return customer;
            }
        }
        return null;
    }

    private static List<LoanManager> findLoansByCustomerNationalId(String nationalId) {
        List<LoanManager> foundLoans = new ArrayList<>();
        for (LoanManager loan : loanList) {
            if (nationalId.equals(loan.getCustomerNationalId())) {
                foundLoans.add(loan);
            }
        }
        return foundLoans;
    }

    private static LoanManager findLoanById(String loanId) {
        for (LoanManager loan : loanList) {
            if (loan.getLoanID().equalsIgnoreCase(loanId)) {
                return loan;
            }
        }
        return null;
    }

    private static void displayAllLoans() {
        System.out.println("All Loans:");
        System.out.println("──────────────────────────────────────────");
        for (int i = 0; i < loanList.size(); i++) {
            LoanManager loan = loanList.get(i);
            System.out.println((i + 1) + ". " + loan.getLoanID() + 
                             " | Type: " + loan.getLoanType() + 
                             " | Amount: RWF " + String.format("%.0f", loan.getLoanAmount()) +
                             " | Status: " + loan.getLoanStatus() +
                             " | Customer: " + (loan.getCustomerName() != null ? loan.getCustomerName() : "Unknown"));
        }
    }

    private static void displayApprovedLoans() {
        System.out.println("Approved Loans:");
        System.out.println("──────────────────────────────────────────");
        boolean found = false;
        for (int i = 0; i < loanList.size(); i++) {
            LoanManager loan = loanList.get(i);
            if (loan.getLoanStatus().equals("APPROVED")) {
                System.out.println((i + 1) + ". " + loan.getLoanID() + 
                                 " | Type: " + loan.getLoanType() + 
                                 " | Status: APPROVED");
                found = true;
            }
        }
        if (!found) {
            System.out.println("No approved loans available.");
        }
    }

    private static String getTypeSpecificAttribute(String loanType) {
        loanType = loanType.toUpperCase();

        switch (loanType) {
            case "PERSONAL", "1" -> {
                String employmentStatus;
                do {
                    System.out.print("Employment Status (EMPLOYED/UNEMPLOYED): ");
                    employmentStatus = scanner.nextLine().toUpperCase().trim();
                } while (!employmentStatus.matches("^(EMPLOYED|UNEMPLOYED)$"));
                return employmentStatus;
            }
            case "HOME", "2" -> {
                String propertyValue;
                do {
                    System.out.print("Property Value (RWF): ");
                    propertyValue = scanner.nextLine().trim();
                } while (!InputValidator.validateMoneyAmount(propertyValue));
                return propertyValue;
            }
            case "CAR", "3" -> {
                String vehicleType;
                do {
                    System.out.print("Vehicle Type (SEDAN/SUV/LUXURY/STANDARD): ");
                    vehicleType = scanner.nextLine().toUpperCase().trim();
                } while (!vehicleType.matches("^(SEDAN|SUV|LUXURY|STANDARD)$"));
                return vehicleType;
            }
            case "BUSINESS", "4" -> {
                String businessType;
                do {
                    System.out.print("Business Type (STARTUP/ESTABLISHED): ");
                    businessType = scanner.nextLine().toUpperCase().trim();
                } while (!businessType.matches("^(STARTUP|ESTABLISHED)$"));
                return businessType;
            }
            case "EDUCATION", "5", "STUDENT" -> {
                String universityName;
                do {
                    System.out.print("University Name: ");
                    universityName = scanner.nextLine().toUpperCase().trim();
                } while (!InputValidator.validateNames(universityName));
                return universityName;
            }
            case "AGRICULTURAL", "6" -> {
                String farmSize;
                do {
                    System.out.print("Farm Size (hectares): ");
                    farmSize = scanner.nextLine().trim();
                } while (!InputValidator.validateMoneyAmount(farmSize));
                return farmSize;
            }
            default -> {
                String additionalInfo;
                do {
                    System.out.print("Additional Info: ");
                    additionalInfo = scanner.nextLine().trim();
                } while (!InputValidator.validateNonEmpty(additionalInfo));
                return additionalInfo;
            }
        }
    }
}


