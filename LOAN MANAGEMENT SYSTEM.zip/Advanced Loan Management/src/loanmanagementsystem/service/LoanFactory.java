package loanmanagementsystem.service;

import loanmanagementsystem.model.*;

/**
 * LoanFactory Class
 * Factory pattern to create loan objects based on type
 * Demonstrates Polymorphism
 */
public class LoanFactory {

    /**
     * Normalize loan type to canonical text
     */
    public static String normalizeLoanType(String loanType) {
        if (loanType == null) {
            return null;
        }
        switch (loanType.trim().toUpperCase()) {
            case "1", "PERSONAL" -> {
                return "PERSONAL";
            }
            case "2", "HOME" -> {
                return "HOME";
            }
            case "3", "CAR" -> {
                return "CAR";
            }
            case "4", "BUSINESS" -> {
                return "BUSINESS";
            }
            case "5", "EDUCATION", "STUDENT" -> {
                return "EDUCATION";
            }
            case "6", "AGRICULTURAL" -> {
                return "AGRICULTURAL";
            }
            default -> {
                return null;
            }
        }
    }

    /**
     * Factory method to create appropriate loan type
     * @param loanType The type of loan to create
     * @param loanID Unique loan identifier
     * @param loanAmount The loan amount
     * @param interestRate Interest rate percentage
     * @param loanDuration Duration in months
     * @param officerName Name of loan officer
     * @param branchLocation Branch location
     * @param specificAttribute Type-specific attribute
     * @return A LoanManager object of the specified type
     */
    public static LoanManager createLoan(String loanType, String loanID, double loanAmount,
                                         double interestRate, int loanDuration,
                                         String officerName, String branchLocation,
                                         String specificAttribute) {

        String normalizedLoanType = normalizeLoanType(loanType);
        if (normalizedLoanType == null) {
            System.out.println("Invalid loan type: " + loanType);
            return null;
        }

        return switch (normalizedLoanType) {
            case "PERSONAL" -> new PersonalLoan(loanID, normalizedLoanType, loanAmount,
                    interestRate, loanDuration, officerName, branchLocation, specificAttribute);
            case "HOME" -> new HomeLoan(loanID, normalizedLoanType, loanAmount,
                    interestRate, loanDuration, officerName, branchLocation,
                    Double.parseDouble(specificAttribute));
            case "CAR" -> new CarLoan(loanID, normalizedLoanType, loanAmount,
                    interestRate, loanDuration, officerName, branchLocation, specificAttribute);
            case "BUSINESS" -> new BusinessLoan(loanID, normalizedLoanType, loanAmount,
                    interestRate, loanDuration, officerName, branchLocation, specificAttribute);
            case "EDUCATION" -> new StudentLoan(loanID, normalizedLoanType, loanAmount,
                    interestRate, loanDuration, officerName, branchLocation, specificAttribute);
            case "AGRICULTURAL" -> new AgriculturalLoan(loanID, normalizedLoanType, loanAmount,
                    interestRate, loanDuration, officerName, branchLocation,
                    Double.parseDouble(specificAttribute));
            default -> null;
        };
    }

    /**
     * Get valid loan types
     * @return Array of valid loan types
     */
    public static String[] getValidLoanTypes() {
        return new String[]{"PERSONAL", "HOME", "CAR", "BUSINESS", "EDUCATION", "AGRICULTURAL"};
    }

    /**
     * Display available loan types
     */
    public static void displayLoanTypes() {
        System.out.println("\n┌──────────────────────────────────────────┐");
        System.out.println("│          AVAILABLE LOAN TYPES            │");
        System.out.println("├──────────────────────────────────────────┤");
        System.out.println("│  1. Personal Loan                        │");
        System.out.println("│  2. Home Loan                            │");
        System.out.println("│  3. Car Loan                             │");
        System.out.println("│  4. Business Loan                        │");
        System.out.println("│  5. Education/Student Loan               │");
        System.out.println("│  6. Agricultural Loan                    │");
        System.out.println("└──────────────────────────────────────────┘");
    }
}
