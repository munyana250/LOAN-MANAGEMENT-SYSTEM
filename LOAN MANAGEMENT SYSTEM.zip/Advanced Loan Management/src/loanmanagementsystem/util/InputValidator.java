package loanmanagementsystem.util;

import java.util.HashSet;
import java.util.Set;

/**
 * InputValidator Class
 * Validates all user inputs throughout the banking system
 */
public class InputValidator {

    private static final Set<String> customerIds = new HashSet<>();
    private static final Set<String> loanIDS = new HashSet<>();
    private static final Set<String> nationalIds = new HashSet<>();
    private static final Set<String> paymentIds = new HashSet<>();

    // ===== CUSTOMER ID VALIDATION =====

    public static boolean validateCustomerIds(String input) {
        if (!validateNonEmpty(input)) return false;
        try {
            if (!input.matches("^CUS-\\d{5}$")) {
                System.out.println("Invalid Customer ID Format.\n" +
                        "Expected: CUS-XXXXX (e.g., CUS-12345)\n");
                return false;
            }
            if (customerIds.contains(input)) {
                System.out.println("Customer ID already exists. Please enter a unique Customer ID.");
                return false;
            }
        } catch (Exception e) {
            System.out.println("An error occurred while validating the input.");
            return false;
        }
        customerIds.add(input);
        return true;
    }

    // ===== EMPTY INPUT VALIDATION =====

    public static boolean validateNonEmpty(String input) {
        if (input == null || input.isBlank()) {
            System.out.println("This field cannot be empty.");
            return false;
        }
        return true;
    }

    // ===== NAME VALIDATION =====

    public static boolean validateNames(String input) {
        if (!validateNonEmpty(input)) return false;
        try {
            if (!input.matches("^[a-zA-Z\\s]+$")) {
                System.out.println("Invalid name format. Names should only contain letters and spaces.");
                return false;
            }
        } catch (Exception e) {
            System.out.println("An error occurred while validating the name.");
            return false;
        }
        return true;
    }

    // ===== LOCATION VALIDATION =====

    public static boolean validateLocation(String input) {
        if (!validateNonEmpty(input)) return false;
        try {
            if (!input.matches("^[a-zA-Z0-9\\s\\.\\-]+$")) {
                System.out.println("Invalid location format. Use letters, numbers, spaces, periods, or hyphens.");
                return false;
            }
        } catch (Exception e) {
            System.out.println("An error occurred while validating the location.");
            return false;
        }
        return true;
    }

    // ===== NATIONAL ID VALIDATION =====
    public static boolean validateNationalId(String input) {
        if (!validateNonEmpty(input)) return false;
        try {
            if (!input.matches("^\\d{16}$") || !input.startsWith("1")) {
                System.out.println("Invalid National ID Format.\n" +
                        "Expected: 16 digits starting with 1\n");
                return false;
            }
            if (nationalIds.contains(input)) {
                System.out.println("National ID already exists. Please enter a unique National ID.");
                return false;
            }
        } catch (Exception e) {
            System.out.println("An error occurred while validating the National ID.");
            return false;
        }
        nationalIds.add(input);
        return true;
    }

    // ===== PHONE NUMBER VALIDATION =====

    public static boolean validatePhoneNumber(String phoneNumber) {
        if (!validateNonEmpty(phoneNumber)) return false;
        try {
            if (!phoneNumber.matches("^\\+250[0-9]{9}$")) {
                System.out.println("Invalid Phone Number Format.\n" +
                        "Expected: +250XXXXXXXXX (e.g., +250788123456)\n");
                return false;
            }
        } catch (Exception e) {
            System.out.println("An error occurred while validating the phone number.");
            return false;
        }
        return true;
    }

    // ===== LOAN ID VALIDATION =====

    public static boolean validateloanIds(String input) {
        if (!validateNonEmpty(input)) return false;
        try {
            if (!input.matches("^LN-\\d{5}$")) {
                System.out.println("Invalid Loan ID Format.\n" +
                        "Expected: LN-XXXXX (e.g., LN-12345)\n");
                return false;
            }
            if (loanIDS.contains(input)) {
                System.out.println("Loan ID already exists. Please enter a unique Loan ID.");
                return false;
            }
        } catch (Exception e) {
            System.out.println("An error occurred while validating the Loan ID.");
            return false;
        }
        loanIDS.add(input);
        return true;
    }

    // ===== PAYMENT ID VALIDATION =====

    public static boolean validatePaymentId(String input) {
        if (!validateNonEmpty(input)) return false;
        try {
            if (!input.matches("^PAY-\\d{5}$")) {
                System.out.println("Invalid Payment ID Format.\n" +
                        "Expected: PAY-XXXXX (e.g., PAY-12345)\n");
                return false;
            }
            if (paymentIds.contains(input)) {
                System.out.println("Payment ID already exists. Please enter a unique Payment ID.");
                return false;
            }
        } catch (Exception e) {
            System.out.println("An error occurred while validating the Payment ID.");
            return false;
        }
        paymentIds.add(input);
        return true;
    }

    // ===== MONEY AMOUNT VALIDATION =====

    public static boolean validateMoneyAmount(String input) {
        if (!validateNonEmpty(input)) return false;
        try {
            double amount = Double.parseDouble(input);
            if (amount <= 0) {
                System.out.println("Invalid loan amount. Amount must be greater than 0.");
                return false;
            }
            if (amount > 1000000000) {
                System.out.println("Amount exceeds maximum limit of 1 Billion RWF.");
                return false;
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid amount. Please enter a valid number.");
            return false;
        } catch (Exception e) {
            System.out.println("An error occurred while validating the amount.");
            return false;
        }
        return true;
    }

    // ===== INTEREST RATE VALIDATION =====

    public static boolean validateInterestRate(String input) {
        if (!validateNonEmpty(input)) return false;
        try {
            double rate = Double.parseDouble(input);
            if (rate <= 0 || rate > 100) {
                System.out.println("Invalid interest rate. Rate must be between 0 and 100.");
                return false;
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid interest rate. Please enter a valid number.");
            return false;
        }
        return true;
    }

    // ===== LOAN DURATION VALIDATION =====

    public static boolean validateLoanDuration(String input) {
        if (!validateNonEmpty(input)) return false;
        try {
            int duration = Integer.parseInt(input);
            if (duration <= 0) {
                System.out.println("Invalid loan duration. Duration must be greater than 0 months.");
                return false;
            }
            if (duration > 600) {
                System.out.println("Invalid loan duration. Maximum duration is 600 months (50 years).");
                return false;
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid duration. Please enter a valid number.");
            return false;
        }
        return true;
    }

    // ===== LOAN TYPE VALIDATION =====

    public static boolean validateloanType(String loanType) {
        if (!validateNonEmpty(loanType)) return false;
        try {
            Set<String> validLoanTypes = Set.of("1", "2", "3", "4", "5", "6",
                    "PERSONAL", "HOME", "CAR", "BUSINESS", "EDUCATION", "STUDENT", "AGRICULTURAL");
            if (!validLoanTypes.contains(loanType.toUpperCase())) {
                System.out.println("Invalid loan type. Please choose from: PERSONAL, HOME, CAR, BUSINESS, EDUCATION, AGRICULTURAL");
                return false;
            }
        } catch (Exception e) {
            System.out.println("An error occurred while validating the loan type.");
            return false;
        }
        return true;
    }

    // ===== NUMERIC VALIDATION =====

    public static boolean validateNumeric(String input, String fieldName) {
        if (!validateNonEmpty(input)) return false;
        try {
            Double.parseDouble(input);
        } catch (NumberFormatException e) {
            System.out.println("Invalid " + fieldName + ". Please enter a valid number.");
            return false;
        }
        return true;
    }

    // ===== YES/NO VALIDATION =====

    public static boolean validateYesNo(String input) {
        if (!validateNonEmpty(input)) return false;
        if (!input.matches("^[YyNn]$")) {
            System.out.println("Please enter Y (Yes) or N (No).");
            return false;
        }
        return true;
    }

    // ===== CLEAR VALIDATION DATA (For testing) =====

    public static void clearValidationData() {
        customerIds.clear();
        loanIDS.clear();
        nationalIds.clear();
        paymentIds.clear();
    }
}
